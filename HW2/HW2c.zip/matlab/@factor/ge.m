function f = ge(f,alpha)
% Element-wise greater-than-or-equal

f.t = double(f.t >= alpha);


