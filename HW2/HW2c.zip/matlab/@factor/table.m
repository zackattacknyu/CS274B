function t=table(f)
% table : accessor for the elements of the factor F
% t = table(f) returns the table version of f
% See also: factor, variables

% (c) Alexander Ihler 2010

t=f.t;

