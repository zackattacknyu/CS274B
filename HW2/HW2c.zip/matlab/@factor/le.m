function f = le(f,alpha)
% Element-wise less-than-or-equal

f.t = double(f.t <= alpha);


