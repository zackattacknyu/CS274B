function f=uminus(f)
% return the unary negation of the factor f
% f=uminus(f) : unary minus (negation)
f.t=-f.t;
