function e=isempty(f)
% isempty(f): Returns true if the factor is empty (an invalid factor)

% (c) Alexander Ihler 2010

e=isempty(f.t);
%e = (length(f.t)==0);
